'use client';

import { SearchSuggestion } from '@/lib/types';
import Image from 'next/image';
import Link from 'next/link';

interface SearchSuggestionsProps {
  suggestions: SearchSuggestion[];
  query: string;
  isVisible: boolean;
  onSelect: (suggestion: SearchSuggestion) => void;
}

export default function SearchSuggestions({
  suggestions,
  query,
  isVisible,
  onSelect,
}: SearchSuggestionsProps) {
  if (!isVisible || !query || suggestions.length === 0) {
    return null;
  }

  const getMediaTypeLabel = (mediaType: string) => {
    return mediaType === 'movie' ? 'Movie' : 'TV Show';
  };

  const getYear = (dateString?: string) => {
    if (!dateString) return '';
    return new Date(dateString).getFullYear();
  };

  return (
    <div className="absolute top-full left-0 right-0 bg-gray-900 border border-gray-700 rounded-lg shadow-lg z-50 mt-1 max-h-80 overflow-y-auto">
      {suggestions.map((suggestion) => (
        <Link
          key={`${suggestion.media_type}-${suggestion.id}`}
          href={`/${suggestion.media_type}/${suggestion.id}`}
          onClick={() => onSelect(suggestion)}
        >
          <div className="flex items-center p-3 hover:bg-gray-800 cursor-pointer transition-colors border-b border-gray-800 last:border-b-0">
            {suggestion.poster_path ? (
              <div className="w-10 h-15 flex-shrink-0 mr-3">
                <Image
                  src={`https://image.tmdb.org/t/p/w92${suggestion.poster_path}`}
                  alt={suggestion.title}
                  width={40}
                  height={60}
                  className="rounded object-cover"
                />
              </div>
            ) : (
              <div className="w-10 h-15 flex-shrink-0 mr-3 bg-gray-700 rounded flex items-center justify-center">
                <span className="text-gray-400 text-xs">No image</span>
              </div>
            )}
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-white font-medium truncate">
                  {suggestion.title}
                </span>
                <span className="text-xs text-gray-400 flex-shrink-0">
                  ({getYear(suggestion.release_date)})
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span className={`text-xs px-2 py-1 rounded ${
                  suggestion.media_type === 'movie' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-purple-500 text-white'
                }`}>
                  {getMediaTypeLabel(suggestion.media_type)}
                </span>
              </div>
            </div>
          </div>
        </Link>
      ))}
      
      <div className="p-3 border-t border-gray-800">
        <Link
          href={`/search?q=${encodeURIComponent(query)}`}
          className="text-blue-400 hover:text-blue-300 text-sm font-medium block text-center"
        >
          View all results for "{query}"
        </Link>
      </div>
    </div>
  );
}